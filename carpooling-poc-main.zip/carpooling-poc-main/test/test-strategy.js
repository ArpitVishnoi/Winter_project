// Test strategy
// Define X main workflow, with X test-file.js
// e.g:
// Carpooling:
// 1) booking with id check and insurance, validation and withdraw
// 2) booking with id check and insurance, cancelation of 1 booking, validation of the others and withdraw
// 3) ...
// CarpoolingFactory:
// 1) Add safe insurances...
